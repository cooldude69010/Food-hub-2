(function () {
  if (!window.AndroidPrinter || window.__fhShim) return;
  window.__fhShim = true;

  function toast(m) { try { showToast(m); } catch (e) { alert(m); } }

  function setUi(connected, name) {
    var b = document.getElementById("bt-status-btn");
    var t = document.getElementById("bt-status-text");
    if (b) b.classList[connected ? "add" : "remove"]("connected");
    if (t && name) t.textContent = name;
  }

  // Native printer result callback
  window.onNativePrinterResult = function (ok, name) {
    if (ok) {
      try { btCharacteristic = { native: true }; } catch (e) {}
      setUi(true, name || "Printer Ready");
      toast("Bluetooth Printer Connected!");
    } else {
      try { btCharacteristic = null; } catch (e) {}
      setUi(false);
      toast("Could not connect. Is the printer ON and paired?");
    }
  };

  // Simple printer picker
  function pickPrinter(list) {
    var ov = document.createElement("div");
    ov.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px";
    var box = document.createElement("div");
    box.style.cssText = "background:#161616;border:1px solid #FACC15;border-radius:16px;padding:16px;width:100%;max-width:360px;color:#fff;font-family:sans-serif";
    box.innerHTML = '<div style="font-weight:800;margin-bottom:10px;color:#FACC15">Select Printer</div>';
    list.forEach(function (p) {
      var btn = document.createElement("button");
      btn.textContent = p.name;
      btn.style.cssText = "display:block;width:100%;text-align:left;padding:12px;margin-bottom:8px;border-radius:10px;border:0;background:#262626;color:#fff;font-size:15px";
      btn.onclick = function () { document.body.removeChild(ov); toast("Connecting..."); AndroidPrinter.connect(p.address); };
      box.appendChild(btn);
    });
    var cancel = document.createElement("button");
    cancel.textContent = "Cancel";
    cancel.style.cssText = "width:100%;padding:10px;border-radius:10px;border:0;background:#FACC15;color:#000;font-weight:800";
    cancel.onclick = function () { document.body.removeChild(ov); };
    box.appendChild(cancel);
    ov.appendChild(box);
    document.body.appendChild(ov);
  }

  window.connectBluetoothPrinter = async function () {
    var r = AndroidPrinter.getPairedPrinters();
    if (r === "PERMISSION") { toast("Allow Bluetooth permission, then tap again"); return; }
    if (r === "NO_BT") { toast("This device has no Bluetooth"); return; }
    if (r === "BT_OFF") { toast("Please turn Bluetooth ON"); return; }
    var list = [];
    try { list = JSON.parse(r); } catch (e) {}
    if (!list.length) { toast("Pair your printer in Android Bluetooth settings first (PIN 0000/1234)"); return; }
    pickPrinter(list);
  };

  window.sendEscPosBytes = async function (receiptText) {
    if (!AndroidPrinter.isConnected()) return false;
    var ok = AndroidPrinter.print(receiptText);
    if (!ok) { try { btCharacteristic = null; } catch (e) {} setUi(false); throw new Error("print failed"); }
    return true;
  };

  // WebView has no window.print(); use Android's print dialog
  window.print = function () { AndroidPrinter.printPage(); };
})();
