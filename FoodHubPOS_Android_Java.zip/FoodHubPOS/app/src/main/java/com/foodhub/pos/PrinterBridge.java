package com.foodhub.pos;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.UUID;

/** JavaScript bridge: classic-Bluetooth (SPP) ESC/POS thermal printing + system print dialog. */
public class PrinterBridge {

    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final MainActivity activity;
    private final WebView webView;
    private BluetoothSocket socket;
    private OutputStream out;
    private String connectedName = "";

    PrinterBridge(MainActivity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    /** Returns JSON: [{"name":"...","address":"..."}] of paired devices. */
    @SuppressLint("MissingPermission")
    @JavascriptInterface
    public String getPairedPrinters() {
        JSONArray arr = new JSONArray();
        try {
            if (!activity.hasBluetoothPermission()) {
                activity.runOnUiThread(activity::requestBluetoothPermission);
                return "PERMISSION";
            }
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null) return "NO_BT";
            if (!ad.isEnabled()) return "BT_OFF";
            for (BluetoothDevice d : ad.getBondedDevices()) {
                JSONObject o = new JSONObject();
                o.put("name", d.getName() == null ? d.getAddress() : d.getName());
                o.put("address", d.getAddress());
                arr.put(o);
            }
        } catch (Exception ignored) { }
        return arr.toString();
    }

    @JavascriptInterface
    public boolean isConnected() {
        return socket != null && socket.isConnected();
    }

    /** Connects in the background, then calls window.onNativePrinterResult(ok, name). */
    @SuppressLint("MissingPermission")
    @JavascriptInterface
    public void connect(final String address) {
        new Thread(() -> {
            boolean ok = false;
            try {
                disconnect();
                BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                BluetoothDevice dev = ad.getRemoteDevice(address);
                ad.cancelDiscovery();
                BluetoothSocket s = dev.createRfcommSocketToServiceRecord(SPP);
                s.connect();
                socket = s;
                out = s.getOutputStream();
                connectedName = dev.getName() == null ? address : dev.getName();
                ok = true;
            } catch (Exception e) {
                disconnect();
            }
            final boolean result = ok;
            final String name = connectedName;
            webView.post(() -> webView.evaluateJavascript(
                    "window.onNativePrinterResult && window.onNativePrinterResult("
                            + result + "," + JSONObject.quote(name) + ")", null));
        }).start();
    }

    /** Sends receipt text as ESC/POS. Runs on a WebView background thread, so blocking is fine. */
    @JavascriptInterface
    public boolean print(String text) {
        try {
            if (!isConnected() || out == null) return false;
            // Thermal printers have no Rupee glyph; strip other non-ASCII characters.
            String clean = text.replace("\u20B9", "Rs.")
                    .replace("\u2022", "*")
                    .replaceAll("[^\\x00-\\x7F]", "");

            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bos.write(new byte[]{0x1B, 0x40});                    // ESC @  initialise
            bos.write(clean.getBytes("US-ASCII"));
            bos.write(new byte[]{0x0A, 0x0A, 0x0A, 0x0A});        // feed
            bos.write(new byte[]{0x1D, 0x56, 0x41, 0x10});        // GS V  partial cut
            byte[] data = bos.toByteArray();

            for (int i = 0; i < data.length; i += 512) {
                out.write(data, i, Math.min(512, data.length - i));
                out.flush();
            }
            return true;
        } catch (Exception e) {
            disconnect();
            return false;
        }
    }

    /** Replacement for window.print(): opens Android's print dialog (PDF / WiFi printers / print services). */
    @JavascriptInterface
    public void printPage() {
        activity.runOnUiThread(() -> {
            PrintManager pm = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
            PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("FoodHub_Bill");
            pm.print("FoodHub Bill", adapter, new PrintAttributes.Builder().build());
        });
    }

    void disconnect() {
        try { if (out != null) out.close(); } catch (Exception ignored) { }
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
        out = null;
        socket = null;
    }
}
