FOOD HUB POS - ANDROID STUDIO PROJECT
1. Install Android Studio, then File > Open > select this FoodHubPOS folder.
2. Let Gradle sync (it downloads Gradle and the Android SDK parts itself).
3. Debug APK: Build > Build APK(s). File lands in app/build/outputs/apk/debug/
4. Shop-ready signed APK: Build > Generate Signed App Bundle / APK > APK.
5. Edit the app itself in app/src/main/assets/index.html.
Printing: use the "RawBT" option (install RawBT from Play Store and pair your thermal printer in it).
